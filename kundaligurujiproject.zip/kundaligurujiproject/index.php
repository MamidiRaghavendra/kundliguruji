
<?php
include 'header.php'
?>
		 
	<!--================Header Menu Area =================-->
<br><br><br><br><br><br><br><br><br>
<div id="demo" class="carousel slide" data-ride="carousel">

		<!-- Indicators -->
		<ul class="carousel-indicators">
		  <li data-target="#demo" data-slide-to="0" class="active"></li>
		  <li data-target="#demo" data-slide-to="1"></li>
		  <li data-target="#demo" data-slide-to="2"></li>
		</ul>
	  
		<!-- The slideshow -->
		<div class="carousel-inner">
		  <div class="carousel-item active">
			<img src="img/horo.jpg" alt="Los Angeles" style="width:100%;height:500px;">
			<div class="carousel-caption">
    <h3 style="color:white" >HOROSCOPE</h3>
    <p style="color:white">A horoscope is an astrological chart or diagram representing the positions of the Sun, Moon, planets, astrological aspects and sensitive angles at the time of an event, such as the moment of a person's birth.</p>
  </div>
		  </div>
		  <div class="carousel-item">
			<img src="img/shiva p.jpg" alt="" style="width:100%;height:500px;">
		  </div>
		  <div class="carousel-item">
			<img src="img/astro.jpg" alt="New York"  style="width:100%;height:500px;">
			</div>
			<div class="carousel-item">
			<img src="img/mala.jpg" alt="New York" style="width:100%;height:500px;">
			<div class="carousel-caption">
    <h3 style="color:white" >MALA</h3>
    <p style="color:white"> Traditional mala beads consist of 108 beads strung on durable material, finished with a tassel or knotted ends..</p>
  </div>
  
			</div>
	
		</div>
	  
		<!-- Left and right controls -->
		<a class="carousel-control-prev" href="#demo" data-slide="prev" >
		  <span class="carousel-control-prev-icon"></span>
		</a>
		<a class="carousel-control-next" href="#demo" data-slide="next" >
		  <span class="carousel-control-next-icon"></span>
		</a>
	  
		</div>

	<!--================ End Feedback Area =================-->

	<!--================ Start Offered Services Area =================-->
	<section class="service_area section_gap">
		<div class="container">
			<div class="row justify-content-center section-title-wrap">
				<div class="col-lg-12">
					<h1>Our Offered Services</h1>
					<p>

					</p>
				</div>
			</div>

			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="single_service">
					<img src="img/hasta.jpg">
						<a href="#">
							<h4>Hashta Rekha Ka Vishleshan</h4>
						</a>
						<p>
						Complete analysis of lines of hands.
						</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="single_service">
					<img src="img/vastu.jpg">
						<a href="#">
							<h4>Vastu Paramarsh
</h4>
						</a>
						<p>We provide an online/offline solution with full analysis for your home and shop and for your Business. 
							
						</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="single_service">
					<img src="img/milan.jpg">
						<a href="#">
							<h4>Kundali Milan
</h4>
						</a>
						<p>We provide an online/offline solution with full analysis for your horoscope.
			
						</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="single_service">
					<img src="img/dosh.png">
						<a href="#">
							<h4>Kundali Dosh Nivaran
</h4>
						</a>
						<p>We provide an online/offline solution with full analysis for your horoscope what probleam you facing in your daily life.
						
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--================ End Offered Services Area =================-->


	<!--================ Start Appointment Area =================-->

	<!--================ end recent-blog Area =================-->

	<!--================ start footer Area =================-->
	<footer class="footer-area section_gap">
		<div class="container">
			<div class="row">
				<div class="col-lg-2  col-md-6">
					<div class="single-footer-widget">
						<h6>Top Products</h6>
						<ul class="footer-nav">
							<li>
								<a href="#">RUDRAKSHA</a>
							</li>
							<li>
								<a href="#">MALA AND BREADS</a>
							</li>
							<li>
								<a href="#">PUJA PRODUCTS</a>
							</li>
							<li>
								<a href="#">YANTRAS</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4  col-md-6">
					<div class="single-footer-widget mail-chimp">
						<h6 class="mb-20">Contact Us</h6>
						<p>
							56/8, Santa bullevard, Rocky beach
						</p>
						<h3>012-6532-568-9746</h3>
						<h3>012-6532-568-97468</h3>
					</div>
				</div>
				<div class="col-lg-6  col-md-12">
					<div class="single-footer-widget newsletter">
						<h6>Newsletter</h6>
						<p>You can trust us. we only send promo offers, not a single spam.</p>
						<div id="mc_embed_signup">
							<form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
							 method="get" class="form-inline">

								<div class="form-group row">
									<div class="col-lg-7 col-md-6 col-sm-12">
										<input name="EMAIL" placeholder="Your Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address '"
										 required="" type="email">
									</div>

									<div class="col-lg-5 col-md-12">
										<button class="nw-btn main_btn circle">get started
											<span class="lnr lnr-arrow-right"></span>
										</button>
									</div>
								</div>
								<div class="info"></div>
							</form>
						</div>
					</div>
				</div>
			</div>

			<div class="row footer-bottom d-flex justify-content-between">
				<p class="col-lg-8 col-sm-12 footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |<i class="fa fa-heart-o" aria-hidden="true"></i></a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
				</p>
				<div class="col-lg-4 col-sm-12 footer-social">
					<a href="#">
						<i class="fa fa-facebook"></i>
					</a>
					<a href="#">
						<i class="fa fa-twitter"></i>
					</a>
					<a href="#">
						<i class="fa fa-dribbble"></i>
					</a>
					<a href="#">
						<i class="fa fa-behance"></i>
					</a>
				</div>
			</div>
		</div>
	</footer>
	<!--================ End footer Area =================-->



	<!--================ Optional JavaScript =================-->
	<!--================ jQuery first, then Popper.js, then Bootstrap JS =================-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>