<?php
include 'header.php';
?>
<br>
<h1 style='margin-top:300px; text-align:center'>GANESH CHATURTHI PUJA MUHURAT</h1>
<img src="img/gan.jpg" alt="">