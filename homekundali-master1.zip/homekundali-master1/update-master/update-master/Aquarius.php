<?php
include "header.php"
?>
<img src="img/aua.png" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About Aquarius</h1>
<p style="font-size:20px;">Aquarius-born are shy and quiet , but on the other hand they can be eccentric and energetic. However, in both cases, they are deep thinkers and highly intellectual people who love helping others. They are able to see without prejudice, on both sides, which makes them people who can easily solve problems.

Although they can easily adapt to the energy that surrounds them, Aquarius-born have a deep need to be some time alone and away from everything, in order to restore power. People born under the Aquarius sign, look at the world as a place full of possibilities.<br>
<strong>Strengths:</strong> Progressive, original, independent, humanitarian<br>

<strong>Weaknesses:</strong> Runs from emotional expression, temperamental, uncompromising, aloof<br>

<strong>Aquarius likes:</strong> Fun with friends, helping others, fighting for causes, intellectual conversation, a good listener<br>

<strong>Aquarius dislikes:</strong> Limitations, broken promises, being lonely, dull or boring situations, people who disagree with them</p>
</div>
<?php
include "footer.php"

?>