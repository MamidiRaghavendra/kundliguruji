<?php
include "header.php"
?>
<img src="img/cancer1.png" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About Cancer</h1>
<p style="font-size:20px;">Deeply intuitive and sentimental, Cancer can be one of the most challenging zodiac signs to get to know. They are very emotional and sensitive, and care deeply about matters of the family and their home. Cancer is sympathetic and attached to people they keep close. Those born with their Sun in Cancer are very loyal and able to empathize with other people's pain and suffering.<br>
<strong style="color:black">Strengths:</strong> Tenacious, highly imaginative, loyal, emotional, sympathetic, persuasive<br>

<strong style="color:black">Weaknesses:</strong> Moody, pessimistic, suspicious, manipulative, insecure<br>

<strong style="color:black">Cancer likes:</strong> Art, home-based hobbies, relaxing near or in water, helping loved ones, a good meal with friends<br>

<strong style="color:black">Cancer dislikes:</strong> Strangers, any criticism of Mom, revealing of personal life</p>
</div>
<?php
include "footer.php"

?>