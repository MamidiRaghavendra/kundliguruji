<?php
include "header.php"
?>
<img src="img/pis.png" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About pisces</h1>
<p style="font-size:20px;">Pisces are very friendly, so they often find themselves in a company of very different people. Pisces are selfless, they are always willing to help others, without hoping to get anything back.

Pisces is a Water sign and as such this zodiac sign is characterized by empathy and expressed emotional capacity.<br>
<strong style="color:black">Strengths:</strong> Compassionate, artistic, intuitive, gentle, wise, musical<br>

<strong style="color:black">Weaknesses:</strong> Fearful, overly trusting, sad, desire to escape reality, can be a victim or a martyr<br>

<strong style="color:black">Pisces likes:</strong> Being alone, sleeping, music, romance, visual media, swimming, spiritual themes<br>

<strong style="color:black">Pisces dislikes:</strong> Know-it-all, being criticized, the past coming back to haunt, cruelty of any kind</p>
</div>
<?php
include "footer.php"

?>