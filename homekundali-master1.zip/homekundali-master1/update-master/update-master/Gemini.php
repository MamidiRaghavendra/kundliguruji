<?php
include "header.php"
?>
<img src="img/gemini.jpg" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About Gemini</h1>
<p style="font-size:20px;">Expressive and quick-witted, Gemini represents two different personalities in one and you will never be sure which one you will face. They are sociable, communicative and ready for fun, with a tendency to suddenly get serious, thoughtful and restless. They are fascinated with the world itself, extremely curious, with a constant feeling that there is not enough time to experience everything they want to see.<br>
<strong style="color:black">Strengths:</strong> Gentle, affectionate, curious, adaptable, ability to learn quickly and exchange ideas<br>

<strong style="color:black">Weaknesses:</strong> Nervous, inconsistent, indecisive<br>

<strong style="color:black">Gemini likes:</strong> Music, books, magazines, chats with nearly anyone, short trips around the town<br>

<strong style="color:black">Gemini dislikes:</strong> Being alone, being confined, repetition and routine</p>
</div>
<?php
include "footer.php"

?>