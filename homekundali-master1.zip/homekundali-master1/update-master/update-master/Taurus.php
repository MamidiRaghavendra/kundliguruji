<?php
include "header.php"
?>
<img src="img/tarurus.png" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About taurus</h1>
<p style="font-size:20px;">Practical and well-grounded, Taurus is the sign that harvests the fruits of labor. They feel the need to always be surrounded by love and beauty, turned to the material world, hedonism, and physical pleasures. People born with their Sun in Taurus are sensual and tactile, considering touch and taste the most important of all senses. Stable and conservative, this is one of the most reliable signs of the zodiac, ready to endure and stick to their choices until they reach the point of personal satisfaction.<br>
<strong style="color:black">Strengths:</strong> Reliable, patient, practical, devoted, responsible, stable<br>

<strong style="color:black">Weaknesses:</strong> Stubborn, possessive, uncompromising<br>

<strong style="color:black">Taurus likes:</strong> Gardening, cooking, music, romance, high quality clothes, working with hands<br>

<strong style="color:black">Taurus dislikes:</strong> Sudden changes, complications, insecurity of any kind, synthetic fabrics</p>
</div>
<?php
include "footer.php"

?>