<?php
include "header.php"
?>
<br>
<img src="img/aries1.png" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About Aries</h1>
<p style="font-size:20px;">Ruled by Fire, the Ram lives in the moment and moves fast and furiously. They're natural-born leaders, and impossible to ignore! They are always ready to take charge and conquer whatever challenge they meet. Courageous and competitive, Aries is a powerful force, carving paths through new territory to find undiscovered treasures. This fearless sign lives life as a warrior, infusing everything it touches with fire, passion, and strength.</p>

   <h1 style="text-align:center"> <img src="img/aries2.svg" style='height:150px;'>Aries' Symbol: Ram's Head</h1>
<p style="font-size:20px;">

As the first sign in the zodiac, the presence of Aries always marks the beginning of something energetic and turbulent. They are continuously looking for dynamic, speed and competition, always being the first in everything - from work to social gatherings. Thanks to its ruling planet Mars and the fact it belongs to the element of Fire (just like Leo and Sagittarius), Aries is one of the most active zodiac signs. It is in their nature to take action, sometimes before they think about it well.<br>
<strong style="color:black">Strengths:</strong> Courageous, determined, confident, enthusiastic, optimistic, honest, passionate<br>

<strong style="color:black">Weaknesses:</strong> Impatient, moody, short-tempered, impulsive, aggressive<br>

<strong style="color:black">Aries likes:</strong> Comfortable clothes, taking on leadership roles, physical challenges, individual sports<br>

<strong style="color:black">Aries dislikes:</strong> Inactivity, delays, work that does not use one's talents</p>















</div>
<?php
include "footer.php"

?>