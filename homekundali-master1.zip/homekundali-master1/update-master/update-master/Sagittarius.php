<?php
include "header.php"
?>
<img src="img/saga.jpg" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About Sagittarius</h1>
<p style="font-size:20px;">Curious and energetic, Sagittarius is one of the biggest travelers among all zodiac signs. Their open mind and philosophical view motivates them to wander around the world in search of the meaning of life.

Sagittarius is extrovert, optimistic and enthusiastic, and likes changes. Sagittarius-born are able to transform their thoughts into concrete actions and they will do anything to achieve their goals.<br>
<strong style="color:black">Strengths:</strong> Generous, idealistic, great sense of humor<br>

<strong style="color:black">Weaknesses:</strong> Promises more than can deliver, very impatient, will say anything no matter how undiplomatic<br>

<strong style="color:black">Sagittarius likes:</strong> Freedom, travel, philosophy, being outdoors<br>

<strong style="color:black">Sagittarius dislikes:</strong> Clingy people, being constrained, off-the-wall theories, details</p>
</div>
<?php
include "footer.php"

?>