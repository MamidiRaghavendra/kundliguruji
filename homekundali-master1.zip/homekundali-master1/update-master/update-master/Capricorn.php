<?php
include "header.php"
?>
<img src="img/capricon.jpg" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About Capricon</h1>
<p style="font-size:20px;">Capricorn is a sign that represents time and responsibility, and its representatives are traditional and often very serious by nature. These individuals possess an inner state of independence that enables significant progress both in their personal and professional lives. They are masters of self-control and have the ability to lead the way, make solid and realistic plans, and manage many people who work for them at any time. They will learn from their mistakes and get to the top based solely on their experience and expertise.<br>
<strong style="color:black">Strengths:</strong> Responsible, disciplined, self-control, good managers<br>

<strong style="color:black">Weaknesses: </strong>Know-it-all, unforgiving, condescending, expecting the worst<br>

<strong style="color:black">Capricorn likes:</strong> Family, tradition, music, understated status, quality craftsmanship<br>

<strong style="color:black">Capricorn dislikes:</strong> Almost everything at some point</p>
</div>
<?php
include "footer.php"

?>