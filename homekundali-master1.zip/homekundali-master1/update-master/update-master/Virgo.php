<?php
include "header.php"
?>
<img src="img/virgo.png" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About Taurus</h1>
<p style="font-size:20px;">Virgos are always paying attention to the smallest details and their deep sense of humanity makes them one of the most careful signs of the zodiac. Their methodical approach to life ensures that nothing is left to chance, and although they are often tender, their heart might be closed for the outer world. This is a sign often misunderstood, not because they lack the ability to express, but because they won’t accept their feelings as valid, true, or even relevant when opposed to reason.<br>
<strong style="color:black">Strengths:</strong> Loyal, analytical, kind, hardworking, practical<br>

<strong style="color:black">Weaknesses:</strong> Shyness, worry, overly critical of self and others, all work and no play<br>

<strong style="color:black">Virgo likes:</strong> Animals, healthy food, books, nature, cleanliness<br>

<strong style="color:black">Virgo dislikes:</strong> Rudeness, asking for help, taking center stage</p>
</div>
<?php
include "footer.php"

?>