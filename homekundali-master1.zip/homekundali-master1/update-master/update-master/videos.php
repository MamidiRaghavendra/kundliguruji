<?php  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-sm-6">
				 <div class="embed-responsive embed-responsive-16by9">
    				<iframe class="embed-responsive-item" src="https://youtu.be/6TNE-i8ZvKs"></iframe>
  				</div>
			</div>
			<div class="col-lg-3 col-sm-6">
				<div class="embed-responsive embed-responsive-1by1">
  					<iframe class="embed-responsive-item" src="https://youtu.be/KULtHuLG9Us" allowfullscreen></iframe>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6">
				<div class="embed-responsive embed-responsive-1by1">
  					<iframe class="embed-responsive-item" src="https://www.youtube.com/watch?v=ELkrJiO1FIw" allowfullscreen></iframe>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6">
				<div class="embed-responsive embed-responsive-1by1">
  					<iframe class="embed-responsive-item" src="https://www.youtube.com/watch?v=4putUxWwg7M" allowfullscreen></iframe>
				</div>
			</div>
		</div>
	</div>

	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
	<script src="vendors/isotope/isotope-min.js"></script>
	<script src="vendors/owl-carousel/owl.carousel.min.js"></script>
	<script src="js/jquery.ajaxchimp.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
	<script src="js/mail-script.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>