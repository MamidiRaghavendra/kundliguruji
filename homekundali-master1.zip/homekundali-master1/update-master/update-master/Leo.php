<?php
include "header.php"
?>
<img src="img/leo.jpg" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About leo</h1>
<p style="font-size:20px;"> They are dramatic, creative, self-confident, dominant and extremely difficult to resist, able to achieve anything they want to in any area of life they commit to. There is a specific strength to a Leo and their "king of the jungle" status. Leo often has many friends for they are generous and loyal. Self-confident and attractive, this is a Sun sign capable of uniting different groups of people and leading them as one towards a shared cause, and their healthy sense of humor makes collaboration with other people even easier.
People born under the sign of Leo are natural born leaders.<br>
<strong style="color:black">Strengths:</strong> Creative, passionate, generous, warm-hearted, cheerful, humorous<br>

<strong style="color:black">Weaknesses:</strong> Arrogant, stubborn, self-centered, lazy, inflexible<br>

<strong style="color:black">Leo likes:</strong> Theater, taking holidays, being admired, expensive things, bright colors, fun with friends<br>

<strong style="color:black">Leo dislikes:</strong> Being ignored, facing difficult reality, not being treated like a king or queen</p>
</div>
<?php
include "footer.php"

?>