<?php
include "header.php"
?>
<img src="img/libya.jpg" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About Libra</h1>
<p style="font-size:20px;">People born under the sign of Libra are peaceful, fair, and they hate being alone. Partnership is very important for them, as their mirror and someone giving them the ability to be the mirror themselves. These individuals are fascinated by balance and symmetry, they are in a constant chase for justice and equality, realizing through life that the only thing that should be truly important to themselves in their own inner core of personality. This is someone ready to do nearly anything to avoid conflict, keeping the peace whenever possible<br>
<strong style="color:black">Strengths:</strong> Cooperative,diplomatic, gracious, fair-minded, social<br>
<strong style="color:black"> Weaknesses:</strong> Indecisive, avoids confrontations, will carry a grudge, self-pity<br>

<strong style="color:black">Libra likes:</strong> Harmony, gentleness, sharing with others, the outdoors<br>

<strong style="color:black">Libra dislikes:</strong> Violence, injustice, loudmouths, conformity</p>
</div>
<?php
include "footer.php"

?>