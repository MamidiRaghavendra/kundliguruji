<?php
include "header.php"
?>
<img src="img/scorpio.png" style="height:500px;width:500px;margin-top:17%;margin-left:30%;">
<div class="container">
<h1 style="text-align:center">About scorpio</h1>
<p style="font-size:20px;">Scorpio-born are passionate and assertive people. They are determined and decisive, and will research until they find out the truth. Scorpio is a great leader, always aware of the situation and also features prominently in resourcefulness.

Scorpio is a Water sign and lives to experience and express emotions. Although emotions are very important for Scorpio, they manifest them differently than other water signs. In any case, you can be sure that the Scorpio will keep your secrets, whatever they may be.<br>
<strong style="color:black">Strengths:</strong> Resourceful, brave, passionate, stubborn, a true friend<br>

<strong style="color:black">Weaknesses:</strong> Distrusting, jealous, secretive, violent<br>

<strong style="color:black">Scorpio likes:</strong> Truth, facts, being right, longtime friends, teasing, a grand passion<br>

<strong style="color:black">Scorpio dislikes:</strong> Dishonesty, revealing secrets, passive people</p>
</div>
<?php
include "footer.php"

?>
