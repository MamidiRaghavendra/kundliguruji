<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="icon" href="img/favicon.png" type="image/png">
	<title>kundaligurujii</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="vendors/linericon/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
	<link rel="stylesheet" href="vendors/lightbox/simpleLightbox.css">
	<link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
	<link rel="stylesheet" href="vendors/animate-css/animate.css">
	<link rel="stylesheet" href="vendors/jquery-ui/jquery-ui.css">
	<!-- main css -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
	<style>
		body {font-family: Arial, Helvetica, sans-serif;}
		
		/* Full-width input fields */
		input[type=text], input[type=password] {
		  width: 100%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  box-sizing: border-box;
		}
		
		/* Set a style for all buttons */
		button {
		  background-color: #4CAF50;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  cursor: pointer;
		  width: 100%;
		}
		
		button:hover {
		  opacity: 0.8;
		}
		
		/* Extra styles for the cancel button */
		.cancelbtn {
		  width: auto;
		  padding: 10px 18px;
		  background-color: #f44336;
		}
		
		/* Center the image and position the close button */
		.imgcontainer {
		  text-align: center;
		  margin: 24px 0 12px 0;
		  position: relative;
		}
		
		img.avatar {
		  width: 40%;
		  border-radius: 50%;
		}
		
		.container {
		  padding: 16px;
		}
		
		span.psw {
		  float: right;
		  padding-top: 16px;
		}
		
		/* The Modal (background) */
		.modal {
		  display: none; /* Hidden by default */
		  position: fixed; /* Stay in place */
		  z-index: 1; /* Sit on top */
		  left: 0;
		  top: 0;
		  width: 100%; /* Full width */
		  height: 100%; /* Full height */
		  overflow: auto; /* Enable scroll if needed */
		  background-color: rgb(0,0,0); /* Fallback color */
		  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
		  padding-top: 60px;
		}
		
		/* Modal Content/Box */
		.modal-content {
		  background-color: #fefefe;
		  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
		  border: 1px solid #888;
		  width: 80%; /* Could be more or less, depending on screen size */
		}
		
		/* The Close Button (x) */
		.close {
		  position: absolute;
		  right: 25px;
		  top: 0;
		  color: #000;
		  font-size: 35px;
		  font-weight: bold;
		}
		
		.close:hover,
		.close:focus {
		  color: red;
		  cursor: pointer;
		}
		
		/* Add Zoom Animation */
		.animate {
		  -webkit-animation: animatezoom 0.6s;
		  animation: animatezoom 0.6s
		}
		
		@-webkit-keyframes animatezoom {
		  from {-webkit-transform: scale(0)} 
		  to {-webkit-transform: scale(1)}
		}
		  
		@keyframes animatezoom {
		  from {transform: scale(0)} 
		  to {transform: scale(1)}
		}
		
		/* Change styles for span and cancel button on extra small screens */
		@media screen and (max-width: 300px) {
		  span.psw {
			 display: block;
			 float: none;
		  }
		  .cancelbtn {
			 width: 100%;
		  }
		}
		</style>
			<style>
		body {font-family: Arial, Helvetica, sans-serif;}
		
		/* Full-width input fields */
		input[type=text], input[type=password] {
		  width: 100%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  box-sizing: border-box;
		}
		
		/* Set a style for all buttons */
		button {
		  background-color: #4CAF50;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  cursor: pointer;
		  width: 100%;
		}
		
		button:hover {
		  opacity: 0.8;
		}
		
		/* Extra styles for the cancel button */
		.cancelbtn {
		  width: auto;
		  padding: 10px 18px;
		  background-color: #f44336;
		}
		
		/* Center the image and position the close button */
		.imgcontainer {
		  text-align: center;
		  margin: 24px 0 12px 0;
		  position: relative;
		}
		
		img.avatar {
		  width: 40%;
		  border-radius: 50%;
		}
		
		.container {
		  padding: 16px;
		}
		
		span.psw {
		  float: right;
		  padding-top: 16px;
		}
		
		/* The Modal (background) */
		.modal {
		  display: none; /* Hidden by default */
		  position: fixed; /* Stay in place */
		  z-index: 1; /* Sit on top */
		  left: 0;
		  top: 0;
		  width: 100%; /* Full width */
		  height: 100%; /* Full height */
		  overflow: auto; /* Enable scroll if needed */
		  background-color: rgb(0,0,0); /* Fallback color */
		  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
		  padding-top: 60px;
		}
		
		/* Modal Content/Box */
		.modal-content {
		  background-color: #fefefe;
		  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
		  border: 1px solid #888;
		  width: 80%; /* Could be more or less, depending on screen size */
		}
		
		/* The Close Button (x) */
		.close {
		  position: absolute;
		  right: 25px;
		  top: 0;
		  color: #000;
		  font-size: 35px;
		  font-weight: bold;
		}
		
		.close:hover,
		.close:focus {
		  color: red;
		  cursor: pointer;
		}
		
		/* Add Zoom Animation */
		.animate {
		  -webkit-animation: animatezoom 0.6s;
		  animation: animatezoom 0.6s
		}
		
		@-webkit-keyframes animatezoom {
		  from {-webkit-transform: scale(0)} 
		  to {-webkit-transform: scale(1)}
		}
		  
		@keyframes animatezoom {
		  from {transform: scale(0)} 
		  to {transform: scale(1)}
		}
		
		/* Change styles for span and cancel button on extra small screens */
		@media screen and (max-width: 300px) {
		  span.psw {
			 display: block;
			 float: none;
		  }
		  .cancelbtn {
			 width: 100%;
		  }
		}
		</style>
</head>

<body>



	<!--================Header Menu Area =================-->
	<header class="header_area">
		

		<div style="width:100%;background-color:rgb(253, 62, 62);color:rgb(255, 255, 255);font-size: 20px;text-align: center; font-family: cursive">Worry about career- 
			<a href="talktoexpert.php" class="btn btn-dark" STYLE="font-family: cursive;">TALK TO OUR EXPERT</a>
		</div>
	
		
		<div class="main_menu ">
			<nav class="navbar navbar-expand-lg navbar-light" style="background-color: rgb(255, 174, 24)">
				<div class="container">

					<a class="navbar-brand logo_h" href="index.html">
						&nbsp;&nbsp;<img src="img/logo.png"  style="width:40%; height:100px;"alt="">
					</a>
					
					<div class="d-lg-block d-sm-none d-xs-none d-none">
						&nbsp;	&nbsp;	&nbsp;	&nbsp;	&nbsp;	<i class="fa fa-hand-o-down" aria-hidden="true"> Our details</i>
						<ul class="right_side">
							<li>
					
								<a href="login.html">
								<i class="fa fa-volume-control-phone" aria-hidden="true" style="color:green;"></i>
									:<strong style="color:white;">09711277386</strong>
								</a>
							</li>
							<li>
							
								<a href="#">
								<i class="fa fa-envelope" aria-hidden="true" style="color:green;"></i>	:<strong style="color:white;">kundaligurujii@.com</strong>
								</a>
					</li>
						<li>
								<a href="#">
							
								<i class="fa fa-facebook" aria-hidden="true" style="color:green;"></i>:<strong style="color:white;">Facebook</strong>
								</a>
							
							</li>
						</ul>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->

				

					<button class='d-lg-block d-sm-none d-xs-none d-none' onclick="document.getElementById('id01').style.display='block'" style=" width:80px; background-color: rgb(158, 75, 75);">Login</button>
					
					<div id="id01" class="modal">
					  
					  <form class="modal-content animate" action="/action_page.php">
						<div class="imgcontainer">
						  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
						  <img src="img/avatar2.png" alt="Avatar" class="avatar" style="width:100px;">
						</div>
					
						<div class="container">
						  <label for="uname"><b>Email</b></label>
						  <input type="text" placeholder="Enter Email" name="uname" required>
					
						  <label for="psw"><b>Password</b></label>
							<input type="password" placeholder="Enter Password" name="psw" required>
							
				
							
						  <button type="submit">Login</button>
						  <label>
							<input type="checkbox" checked="checked" name="remember"> Remember me
						  </label>
						</div>
					
						<div class="container" style="background-color:#f1f1f1">
						  <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
						  <span class="psw">Forgot <a href="#">password?</a></span>
						</div>
					  </form>
					</div>
					
					<button class='d-lg-block d-sm-none d-xs-none d-none' onclick="document.getElementById('id01').style.display='block'" style="width:auto; background-color: rgb(158, 75, 75)">register</button>
					
					<div id="id01" class="modal">
					  
					  <form class="modal-content animate" action="/action_page.php">
						<div class="imgcontainer">
						  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
						  <img src="img/avatar2.png" alt="Avatar" class="avatar" style="width:100px;">
						</div>
					
						<div class="container">
						  <label for="uname"><b>Email</b></label>
						  <input type="text" placeholder="Enter Email" name="uname" required>
						  
					
						  <label for="psw"><b>Password</b></label>
						  <input type="password" placeholder="Enter Password" name="psw" required>
						  
						  <label for="uname"><b>Confirm Password</b></label>
						  <input type="text" placeholder="Enter Confirm passsword" name="uname" required>
						
						
				
						 
							
						  <button type="submit">register</button>
						  <label>
							<input type="checkbox" checked="checked" name="remember"> Remember me
						  </label>
						</div>
					
						<div class="container" style="background-color:#f1f1f1">
						  <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
						  <span class="psw">Forgot <a href="#">password?</a></span>
						</div>
					  </form>
					</div>
					
					<script>
					// Get the modal
					var modal = document.getElementById('id01');
					
					// When the user clicks anywhere outside of the modal, close it
					window.onclick = function(event) {
						if (event.target == modal) {
							modal.style.display = "none";
						}
					}
					</script>

				</div>
				<img src="img/nam.jpg"  class='d-lg-block d-sm-none d-xs-none d-none' style="width:10%;">

			</nav>
		</div>
		
		
		
		
		<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
				<!-- Brand -->
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    		 MENU <span class="navbar-toggler-icon"></span>
				<span class="navbar-toggler-icon"></span>
				<span class="navbar-toggler-icon"></span>
  </button>
			  
				<!-- Links -->
			<div class="collapse navbar-collapse" id="navbarTogglerDemo03">
				
				<ul class="navbar-nav mr-auto mt-2 mt-lg-0v" >
				  <li class="nav-item">
					<a class="nav-link" href="#" >HOME</a>
				  </li>
					<li class="nav-item d-lg-none d-md-none d-sm-block d-xs-block " >
					<button class='nav-link' onclick="document.getElementById('id01').style.display='block'" style=" width:80px; background-color: rgb(158, 75, 75);">Login</button>
					</li>

					<li class="nav-item  d-lg-none d-md-none d-sm-block d-xs-block">
					<button class='nav-link' onclick="document.getElementById('id01').style.display='block'" style="width:auto; background-color: rgb(158, 75, 75)">register</button>
					</li>

				  <li class="nav-item">
					<a class="nav-link" href="shop.php">SHOP</a>
				  </li>
				  <li class="nav-item">
						<a class="nav-link" href="#">DIWALI SPECIAL</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" href="#">PUJA KITS</a>
					  </li>
					  <li class="nav-item">
							<a class="nav-link" href="#">YANTRAS</a>
							</li>
							<li class="nav-item">
							<a class="nav-link" href="#">RUDRAKSHA</a>
							</li>
							<li class="nav-item">
							<a class="nav-link" href="#">LEARN ASTROLOGY</a>
							</li>
							<li class="nav-item">
							<a class="nav-link" href="#">VASTU</a>
							</li>
							
					
				  <!-- Dropdown -->
				  
		
				  <li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
						SPIRITUAL GURUS 
						</a>
						<div class="dropdown-menu">
						  <a class="dropdown-item" href="#">Astrologer</a>
						  <a class="dropdown-item" href="#">Pandit</a>
						  <a class="dropdown-item" href="#">Numerologist</a>
							<a class="dropdown-item" href="#">Gemologist</a>
							<a class="dropdown-item" href="#">Tarot Card reader</a>
						</div>
					  </li>
					  <li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
						 TEMPLES AND PRASAD
							</a>
							<div class="dropdown-menu">
							  <a class="dropdown-item" href="#">Siddhi Vinayak Mandir & Prasad</a>
							  <a class="dropdown-item" href="#">Vaishno Devi Temple & Prasad</a>
							  <a class="dropdown-item" href="#">Shani Shingapur Temple & Prasad</a>
							</div>
						  </li>
						  <li class="nav-item dropdown">
								<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
							MUHURAT 
								</a>
								<div class="dropdown-menu">
								  <a class="dropdown-item" href="Griha Pravesh Muhurat.php">Griha Pravesh Muhurat</a>
								  <a class="dropdown-item" href="vehicle muhurat.php">Vehicle Purchase Muhurat</a>
								  <a class="dropdown-item" href="Marriage Muhurat.php">Marriage Muhurat</a>
									<a class="dropdown-item" href="Ganesh Chaturthi Puja Muhurat.php">Ganesh Chaturthi Puja Muhurat</a>
									<a class="dropdown-item" href=" Krishna Janamashtami Puja Muhurat.php">Krishna Janamashtami Puja Muhurat</a>
								
									<a class="dropdown-item" href="Godhuli Lagna.php">Godhuli Lagna</a>
								
								</div>
							  </li>
							  <li class="nav-item dropdown">
									<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
								VIDEOS
									</a>
									<div class="dropdown-menu">
									  <a class="dropdown-item" href="https://www.facebook.com/kundaliguruji/videos/vb.370746517088704/2227388450710042/?type=2&theater">Ganga Aarti</a>
									  <a class="dropdown-item" href="https://www.facebook.com/kundaliguruji/videos/301289200819640/">Ganesh Aarti</a>
									  <a class="dropdown-item" href="https://www.facebook.com/kundaliguruji/videos/2060886170886320/">Apni kundali ko jaane....</a>
										<a class="dropdown-item" href="https://www.facebook.com/kundaliguruji/videos/518175732057304/">#kundalilagan #kundaliguruji</a>
										<a class="dropdown-item" href="https://www.facebook.com/kundaliguruji/videos/673421106445927/">Maha kaal Basam Aarti </a>
										<a class="dropdown-item" href="https://www.facebook.com/kundaliguruji/videos/461322371270296/">Maha kaal  Aarti</a>
									</div>
								  </li>
								  <li class="nav-item">
										<a class="nav-link" href="#">BLOG</a>
									  </li>
				</ul>

				</div>
			  </nav>
			  
	</header>