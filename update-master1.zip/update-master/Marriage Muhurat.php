<?php
include 'header.php';
?>
<br>
<h1 style='margin-top:300px; text-align:center'>MARRIAGE MUHURAT</h1>
<img src="img/mar.jpg" alt="">